public interface MotorcycleSpecs {
    void specifyWheelCount(int wheelTotal);
    int retrieveWheelCount();
    void specifyMotorcycleStyle(String styleCategory);
    String retrieveMotorcycleStyle();
}
