public interface CarDetails {
    void assignDoorCount(int doorCount);
    int fetchDoorCount();
    void assignFuelType(String fuelCategory);
    String fetchFuelType();
}
