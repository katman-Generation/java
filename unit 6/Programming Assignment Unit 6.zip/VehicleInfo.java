public interface VehicleInfo {
    String retrieveMake();
    String retrieveModel();
    int retrieveManufactureYear();
}
