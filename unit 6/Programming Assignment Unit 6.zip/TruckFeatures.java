public interface TruckFeatures {
    void defineCargoCapacity(double tonCapacity);
    double getCargoCapacity();
    void defineTransmissionMode(String gearType);
    String getTransmissionMode();
}
